#PyWatcher v1
By: **Andrew J. George** with help from **Ashton Webster** (and of course, the cool people on StackOverflow)
<br>
<br>
Just a little utility for tracking the uptime of a network device. 

PyWatcher.py will let you build, save, delete, and save watchers. <br>
(Note, changes you make in PyWatcher.py **will not be saved** until you save them.
 This includes both creation and deletion of watchers.)

Watchers will not continue running when you close PyWatcher.
If you want to run the watchers that you have created in the background run **PyWatcher_background.pyw** <br>
This will run all the watchers you currently have saved. You can kill this process in task manager. 
<br>
<br>
<br>

If you find this useful, I take tips! https://www.paypal.me/MythReeLives
